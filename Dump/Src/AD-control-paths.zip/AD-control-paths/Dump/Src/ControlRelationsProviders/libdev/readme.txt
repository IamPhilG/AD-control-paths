Extract ADCP-libdev in this directory (\libdev).
https://github.com/ANSSI-FR/ADCP-libdev

Stucture must be:
\libdev
 \Include  -> Include files (*.h)
 \Debug    -> 32-bit debug (*.lib/*.pdb)
 \Release  -> 32-bit release (*.lib/*.pdb)
 \x64
  \Debug   -> 64-bit debug (*.lib/*.pdb)
  \Release -> 64-bit release (*.lib/*.pdb)
