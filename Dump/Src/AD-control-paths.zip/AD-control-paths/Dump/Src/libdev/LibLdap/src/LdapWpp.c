/******************************************************************************\
Author : X. XXXXXX
Date   : 01/01/1970
Descr. : XXX XXX XXX XXX XXX XXX XXX XXX XXX
XXX XXX XXX XXX XXX XXX XXX XXX XXX
XXX XXX XXX XXX XXX XXX XXX XXX XXX
\******************************************************************************/

/* --- INCLUDES ------------------------------------------------------------- */
#ifdef _WIN32
    #include "LdapWpp.h"
    #include "LdapWpp.tmh"
#endif

//
// Regenerate *.tmh files:
//      tracewpp.exe -cfgdir:"<WindowsKitDir>\bin\WppConfig\Rev1" -scan:"LdapWpp.h" *.c
//

/* --- PRIVATE VARIABLES ---------------------------------------------------- */
/* --- PUBLIC VARIABLES ----------------------------------------------------- */
/* --- PRIVATE FUNCTIONS ---------------------------------------------------- */
/* --- PUBLIC FUNCTIONS ----------------------------------------------------- */
